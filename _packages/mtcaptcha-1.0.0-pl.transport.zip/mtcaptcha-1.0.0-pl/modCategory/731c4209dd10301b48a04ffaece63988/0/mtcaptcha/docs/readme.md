
mtCaptcha

Author: Jan Dähne <https://www.quadro-system.de>
Copyright 2022

Official Documentation: https://www.quadro-system.de/modx-extras/mtCaptcha/

Bugs and Feature Requests: https://github.com/QUADRO-web/mtCaptcha

Questions: http://forums.modx.com
