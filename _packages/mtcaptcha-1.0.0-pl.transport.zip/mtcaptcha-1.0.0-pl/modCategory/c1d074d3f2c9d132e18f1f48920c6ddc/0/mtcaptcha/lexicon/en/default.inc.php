<?php
/**
 * German Lexicon Entries
 *
 * @package mtCaptcha
 * @subpackage lexicon
 *
 */

$_lang['mtcaptcha.error'] = 'Error verifying Captcha, please try again.';
