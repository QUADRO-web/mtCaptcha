Changelog for mtCaptcha

mtCaptcha 1.0.0
---------------------------------
+ Initial Version
