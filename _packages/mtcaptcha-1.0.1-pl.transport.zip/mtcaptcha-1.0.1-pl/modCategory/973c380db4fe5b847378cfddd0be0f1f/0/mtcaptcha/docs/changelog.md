Changelog for mtCaptcha

mtCaptcha 1.0.1
---------------------------------
+ Fix lexicon entries (Thanx to Thomas Jakobi: https://github.com/QUADRO-web/mtCaptcha/pull/1)

mtCaptcha 1.0.0
---------------------------------
+ Initial Version
