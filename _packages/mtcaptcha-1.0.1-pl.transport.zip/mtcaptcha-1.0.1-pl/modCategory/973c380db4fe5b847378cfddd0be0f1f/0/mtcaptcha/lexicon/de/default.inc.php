<?php
/**
 * German Lexicon Entries
 *
 * @package mtCaptcha
 * @subpackage lexicon
 *
 */

$_lang['mtcaptcha.error'] = 'Fehler beim Verifizieren des Captchas, bitte versuchen Sie es erneut.';
