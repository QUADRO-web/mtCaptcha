<?php
/**
 * Setting Lexicon Entries
 *
 * @package mtCaptcha
 * @subpackage lexicon
 */
$_lang['setting_mtcaptcha.sitekey'] = 'Site Key';
$_lang['setting_mtcaptcha.privatekey'] = 'Private Key';
